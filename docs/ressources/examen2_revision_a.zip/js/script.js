// Tableau des résutlats (ne pas effacer)
const resultats = [
    { numeroParticipant: 1, nom: "Tremblay", prenom: "Sophie", resultat: "00:24:37", epreuve: "5k" },
    { numeroParticipant: 2, nom: "Lefebvre", prenom: "Marc", resultat: "00:21:15", epreuve: "5k" },
    { numeroParticipant: 3, nom: "Gagnon", prenom: "Julie", resultat: "00:27:48", epreuve: "5k" },
    { numeroParticipant: 4, nom: "Côté", prenom: "Alexandre", resultat: "00:19:52", epreuve: "5k" },
    { numeroParticipant: 5, nom: "Bouchard", prenom: "Isabelle", resultat: "00:25:31", epreuve: "5k" },
    { numeroParticipant: 6, nom: "Roy", prenom: "Philippe", resultat: "00:43:10", epreuve: "10k" },
    { numeroParticipant: 7, nom: "Morin", prenom: "Karine", resultat: "00:52:26", epreuve: "10k" },
    { numeroParticipant: 8, nom: "Pelletier", prenom: "François", resultat: "00:46:39", epreuve: "10k" },
    { numeroParticipant: 9, nom: "Gauthier", prenom: "Chantal", resultat: "01:01:11", epreuve: "10k" },
    { numeroParticipant: 42, nom: "Villeneuve", prenom: "Jean", resultat: "00:39:58", epreuve: "10k" },
    { numeroParticipant: 11, nom: "Girard", prenom: "Marie", resultat: "01:48:37", epreuve: "demi-marathon" },
    { numeroParticipant: 12, nom: "Bergeron", prenom: "Luc", resultat: "01:35:42", epreuve: "demi-marathon" },
    { numeroParticipant: 13, nom: "Caron", prenom: "Annie", resultat: "02:02:15", epreuve: "demi-marathon" },
    { numeroParticipant: 14, nom: "Lapointe", prenom: "David", resultat: "01:29:54", epreuve: "demi-marathon" },
    { numeroParticipant: 15, nom: "Martel", prenom: "Nadia", resultat: "01:56:08", epreuve: "demi-marathon" },
    { numeroParticipant: 16, nom: "Simard", prenom: "Vincent", resultat: "03:12:45", epreuve: "marathon" },
    { numeroParticipant: 17, nom: "Dubé", prenom: "Hélène", resultat: "03:44:11", epreuve: "marathon" },
    { numeroParticipant: 18, nom: "Ouellet", prenom: "Martin", resultat: "02:58:37", epreuve: "marathon" },
    { numeroParticipant: 19, nom: "Lavoie", prenom: "Caroline", resultat: "03:27:22", epreuve: "marathon" },
    { numeroParticipant: 20, nom: "Parent", prenom: "Jean-François", resultat: "04:05:50", epreuve: "marathon" },
    { numeroParticipant: 21, nom: "Beaulieu", prenom: "Catherine", resultat: "00:23:49", epreuve: "5k" },
    { numeroParticipant: 22, nom: "Thibault", prenom: "Simon", resultat: "00:20:42", epreuve: "5k" },
    { numeroParticipant: 23, nom: "Bélanger", prenom: "Émilie", resultat: "00:26:55", epreuve: "5k" },
    { numeroParticipant: 24, nom: "Paquette", prenom: "Étienne", resultat: "00:18:57", epreuve: "5k" },
    { numeroParticipant: 25, nom: "Deschênes", prenom: "Audrey", resultat: "00:29:03", epreuve: "5k" },
    { numeroParticipant: 26, nom: "Vachon", prenom: "Dominic", resultat: "00:48:24", epreuve: "10k" },
    { numeroParticipant: 27, nom: "Noël", prenom: "Geneviève", resultat: "00:50:18", epreuve: "10k" },
    { numeroParticipant: 28, nom: "Cloutier", prenom: "Pascal", resultat: "00:44:42", epreuve: "10k" },
    { numeroParticipant: 29, nom: "Harvey", prenom: "Laurence", resultat: "00:55:27", epreuve: "10k" },
    { numeroParticipant: 30, nom: "Blais", prenom: "Maxime", resultat: "00:41:33", epreuve: "10k" },
    { numeroParticipant: 31, nom: "Boivin", prenom: "Patricia", resultat: "01:42:05", epreuve: "demi-marathon" },
    { numeroParticipant: 32, nom: "Rousseau", prenom: "Samuel", resultat: "01:31:46", epreuve: "demi-marathon" },
    { numeroParticipant: 42, nom: "Villeneuve", prenom: "Jean", resultat: "01:58:19", epreuve: "demi-marathon" },
    { numeroParticipant: 34, nom: "Proulx", prenom: "Guillaume", resultat: "01:24:57", epreuve: "demi-marathon" },
    { numeroParticipant: 35, nom: "Lévesque", prenom: "Isabelle", resultat: "02:05:30", epreuve: "demi-marathon" },
    { numeroParticipant: 36, nom: "Dion", prenom: "Nicolas", resultat: "03:03:10", epreuve: "marathon" },
    { numeroParticipant: 37, nom: "Bérubé", prenom: "Amélie", resultat: "03:50:21", epreuve: "marathon" },
    { numeroParticipant: 38, nom: "Grenier", prenom: "Patrick", resultat: "02:54:49", epreuve: "marathon" },
    { numeroParticipant: 39, nom: "Chouinard", prenom: "Valérie", resultat: "03:39:05", epreuve: "marathon" },
    { numeroParticipant: 40, nom: "Lachance", prenom: "Gabriel", resultat: "04:15:32", epreuve: "marathon" },
    { numeroParticipant: 41, nom: "Lambert", prenom: "Julie", resultat: "00:22:48", epreuve: "5k" },
    { numeroParticipant: 42, nom: "Villeneuve", prenom: "Jean", resultat: "00:25:22", epreuve: "5k" },
    { numeroParticipant: 43, nom: "Langlois", prenom: "Carole", resultat: "00:28:16", epreuve: "5k" },
    { numeroParticipant: 44, nom: "Rivard", prenom: "Olivier", resultat: "00:19:45", epreuve: "5k" },
    { numeroParticipant: 45, nom: "Arsenault", prenom: "Sabrina", resultat: "00:30:02", epreuve: "5k" },
    { numeroParticipant: 46, nom: "Turcotte", prenom: "Pascal", resultat: "00:23:54", epreuve: "5k" },
    { numeroParticipant: 47, nom: "Duguay", prenom: "Myriam", resultat: "00:27:15", epreuve: "5k" },
    { numeroParticipant: 48, nom: "Michaud", prenom: "Luc", resultat: "00:24:11", epreuve: "5k" },
    { numeroParticipant: 49, nom: "Nadeau", prenom: "Patricia", resultat: "00:26:22", epreuve: "5k" },
    { numeroParticipant: 50, nom: "Goulet", prenom: "Antoine", resultat: "00:20:39", epreuve: "5k" },
    { numeroParticipant: 51, nom: "Hamel", prenom: "Cynthia", resultat: "00:29:48", epreuve: "5k" },
    { numeroParticipant: 52, nom: "Dufresne", prenom: "Charles", resultat: "00:21:33", epreuve: "5k" },
    { numeroParticipant: 53, nom: "Audet", prenom: "Sophie", resultat: "00:25:44", epreuve: "5k" },
    { numeroParticipant: 54, nom: "Tardif", prenom: "Francis", resultat: "00:19:59", epreuve: "5k" },
    { numeroParticipant: 55, nom: "Desrosiers", prenom: "Amélie", resultat: "00:28:01", epreuve: "5k" },
    { numeroParticipant: 56, nom: "Dubois", prenom: "Mélanie", resultat: "00:53:08", epreuve: "10k" },
    { numeroParticipant: 57, nom: "Poulin", prenom: "Jonathan", resultat: "00:42:29", epreuve: "10k" },
    { numeroParticipant: 58, nom: "Gaudreault", prenom: "Sophie", resultat: "00:59:12", epreuve: "10k" },
    { numeroParticipant: 59, nom: "Plante", prenom: "David", resultat: "00:47:03", epreuve: "10k" },
    { numeroParticipant: 60, nom: "Bernier", prenom: "Amélie", resultat: "00:54:50", epreuve: "10k" },
    { numeroParticipant: 61, nom: "Lafleur", prenom: "Jean-Philippe", resultat: "00:40:26", epreuve: "10k" },
    { numeroParticipant: 62, nom: "Marchand", prenom: "Nathalie", resultat: "01:03:05", epreuve: "10k" },
    { numeroParticipant: 63, nom: "Barbeau", prenom: "Louis", resultat: "00:38:57", epreuve: "10k" },
    { numeroParticipant: 64, nom: "Carrier", prenom: "Élise", resultat: "00:49:41", epreuve: "10k" },
    { numeroParticipant: 65, nom: "Gravel", prenom: "Mathieu", resultat: "00:45:10", epreuve: "10k" },
    { numeroParticipant: 66, nom: "Perreault", prenom: "Dominique", resultat: "01:47:21", epreuve: "demi-marathon" },
    { numeroParticipant: 67, nom: "Savard", prenom: "Julie", resultat: "01:53:34", epreuve: "demi-marathon" },
    { numeroParticipant: 68, nom: "Gendron", prenom: "Patrick", resultat: "01:39:18", epreuve: "demi-marathon" },
    { numeroParticipant: 69, nom: "Raymond", prenom: "Sabrina", resultat: "02:01:42", epreuve: "demi-marathon" },
    { numeroParticipant: 70, nom: "Beaudoin", prenom: "Alexandre", resultat: "01:33:27", epreuve: "demi-marathon" },
];

/*
Pseudo-code pour l'ajout des résultats à la question #2
(À utiliser si vous le souhaitez)

!!! Ce pseudo-code ne remplace pas l'énoncé de l'examen, attention à bien valider 
que tous les points ont bien été remplis !!!


Supprimer toutes les lignes de résultats de la section tbody

Récupérer tous les résultats qui correspondent au numéro du participant

S'il y a des résultats
    Pour chaque résultat
        Créer une nouvelle ligne de tableau.
        Créer un cellule pour chaque colonne demandée
        Modifier le texte de la cellule selon les informations du résultat
        Ajouter la cellule dans la ligne du tableau
        Ajouter la ligne dans le tableau
    Afficher le nombre de résultats trouvés
    
Si aucun résultat
    Créer une nouvelle ligne de tableau.
    Créer un cellule pour chaque colonne demandée
    Modifier le texte de la cellule pour un tirer
    Ajouter la cellule dans la ligne du tableau
    Ajouter la ligne dans le tableau

    Afficher le message d'erreur qu'il n'y a pas de résultat
    Changer la couleur du texte du message d'erreur en rouge

*/

// Ajouter votre code après cette ligne
