// Test pour s'assurer que le tableau pokemons est disponible
console.table(pokemons);
